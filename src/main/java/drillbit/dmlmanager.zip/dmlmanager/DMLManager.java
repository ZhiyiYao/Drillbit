package drillbit.dmlmanager;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Map;

import drillbit.utils.parser.StringParser;
import drillbit.dmlmanager.SynData;
import drillbit.dmlmanager.synmethed.SynMethed;

public class DMLManager {
	private String localIP;
	private int localPort;

	private ArrayList<String> nodesIP;
	private ArrayList<Integer> nodesPort;
	private int globalPort;

	private State localState;
	private int serverID;

	private enum State {
		server, client
	}

	public DMLManager() {
		nodesIP = new ArrayList<String>();
		nodesPort = new ArrayList<Integer>();
	}

	public void loadConfig() {
		Map<String, String> env = System.getenv();
		String sysPath = env.get("DRILL_HOME") + "/conf/DML.conf";
		InetAddress localHost;
		try {
			localHost = InetAddress.getLocalHost();
		} catch (UnknownHostException e1) {
			throw new RuntimeException(e1.toString());
		}
		localIP = localHost.getHostAddress();

		System.out.print("load configure\n");

		try {
			BufferedReader cfg = new BufferedReader(new FileReader(sysPath));
			while (true) {
				String line = cfg.readLine();
				if (line == null) {
					break;
				}

				int pos = line.indexOf(':');

				if (pos != -1) {
					String nodeIP = line.substring(0, pos);

					if (!nodeIP.equals(localIP)) {
						nodesIP.add(line.substring(0, pos));
						nodesPort.add(StringParser.parseInt(line.substring(pos + 1), 31015));
					} else {
						localPort = StringParser.parseInt(line.substring(pos + 1), 31015);
					}
				} else {
					globalPort = StringParser.parseInt(line, 31016);
				}
			}

			cfg.close();
		} catch (IOException e) {
			throw new RuntimeException(e.toString());
		}
	}

	public void getState() throws RuntimeException {
		int i = 0;
		Socket connectInfo = null;
		String serverHost = "n";
		OutputStream writer = null;
		InputStream reader = null;
		ReactThread r;

		System.out.print("start get state\n");

		for (; i < nodesIP.size(); i++) {
			try {
				connectInfo = new Socket(InetAddress.getByName(nodesIP.get(i)), globalPort);
				writer = connectInfo.getOutputStream();

				writer.write("c".getBytes());
				connectInfo.shutdownOutput();

				reader = connectInfo.getInputStream();
				ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
				byte[] buf = new byte[20];
				int l;
				while ((l = reader.read(buf)) != -1) {
					byteArray.write(buf, 0, l);
				}
				serverHost = byteArray.toString();

				for (int j = 0; j < nodesIP.size(); j++) {
					if (nodesIP.get(j).equals(serverHost)) {
						serverID = j;
						break;
					}
				}

				System.out.println("connet to " + serverHost);
			} catch (UnknownHostException e) {
				;
			} catch (IOException e) {
				;
			} finally {
				if (connectInfo != null) {
					try {
						connectInfo.close();
					} catch (IOException e) {
						throw new RuntimeException(e.toString());
					}
				}
				if (writer != null) {
					try {
						writer.close();
					} catch (IOException e) {
						throw new RuntimeException(e.toString());
					}
				}
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						throw new RuntimeException(e.toString());
					}
				}
			}

			if (!serverHost.equals("n")) {
				break;
			}
		}

		if (!serverHost.equals("n")) {
			localState = State.client;

			r = new ReactThread(nodesIP.get(serverID), globalPort);
		} else {
			serverID = -1;
			localState = State.server;

			System.out.print("be server\n");

			r = new ReactThread(localIP, globalPort);
		}

		r.start();

		System.out.println("test synchronize...");
		int flag = synchronize(1);

		if (flag != nodesIP.size() + 1) {
			throw new RuntimeException("get state failed!");
		}

		try {
			Socket shutDownServer = new Socket(localIP, globalPort);
			writer = shutDownServer.getOutputStream();

			writer.write("o".getBytes());
			shutDownServer.shutdownOutput();
			shutDownServer.close();
		} catch (UnknownHostException e) {
			throw new RuntimeException("shut down server failed!");
		} catch (IOException e) {
			throw new RuntimeException("shut down server failed!");
		}
	}

	public int synchronize(int data) {
		int sum = -1;
		int nodeNum = nodesIP.size();

		if (localState == State.server) {
			ServerSocket dataServer;
			Socket client;

			sum = data;
			try {
				System.out.println("server try to get data");

				for (int i = 0; i < nodeNum; i++) {

					dataServer = new ServerSocket(localPort);
					System.out.println("server port :" + localPort);
					client = dataServer.accept();
					InputStream reader = client.getInputStream();
					ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
					System.out.println("server receive data");

					byte[] buf = new byte[20];
					int l;
					while ((l = reader.read(buf)) != -1) {
						byteArray.write(buf, 0, l);
					}
					sum += StringParser.parseInt(byteArray.toString(), 0);

					client.close();
					dataServer.close();
				}
				System.out.println("server send data start");

				for (int i = 0; i < nodeNum; i++) {
					System.out.println("server send data:" + nodesIP.get(i) + ":" + nodesPort.get(i));
					client = new Socket(nodesIP.get(i), nodesPort.get(i));
					OutputStream writer = client.getOutputStream();

					writer.write(Integer.toString(sum).getBytes());
					client.shutdownOutput();
					System.out.println("over");
				}
			} catch (IOException e) {
				throw new RuntimeException(e.toString());
			}
		} else {
			ServerSocket server;
			try {
				server = new ServerSocket(localPort);
			} catch (IOException e1) {
				throw new RuntimeException(e1.toString());
			}

			System.out.println(nodesIP.get(serverID) + ":" + nodesPort.get(serverID));

			while (true) {

				try {
					Socket client = new Socket(nodesIP.get(serverID), nodesPort.get(serverID));
					System.out.println("socket ok");
					OutputStream writer = client.getOutputStream();
					ByteArrayOutputStream byteArray = new ByteArrayOutputStream();

					writer.write(Integer.toString(data).getBytes());
					client.shutdownOutput();

					Socket reciever = server.accept();
					InputStream reader = reciever.getInputStream();

					System.out.println("client start recieve data");

					byte[] buf = new byte[20];
					int l;
					while ((l = reader.read(buf)) != -1) {
						byteArray.write(buf, 0, l);
					}
					System.out.print("recieve over");

					reciever.close();
					server.close();
					System.out.println("client recieve data: " + byteArray.toString());

					sum = StringParser.parseInt(byteArray.toString(), 0);
					System.out.println(sum);
				} catch (UnknownHostException e) {
					;
				} catch (IOException e) {
					;
				}

				if (sum != -1) {
					break;
				}
			}
		}

		return sum;
	}

	public byte[] synchronize(SynData data,SynMethed methed,int maxbuf) {
		SynData sum = data;
		byte[] result = null;
		int nodeNum = nodesIP.size();

		if (localState == State.server) {
			ServerSocket dataServer;
			Socket client;

			sum = data;
			try {
				System.out.println("server try to get data");

				for (int i = 0; i < nodeNum; i++) {

					dataServer = new ServerSocket(localPort);
					System.out.println("server port :" + localPort);
					client = dataServer.accept();
					InputStream reader = client.getInputStream();
					ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
					System.out.println("server receive data");

					byte[] buf = new byte[maxbuf];
					int l;
					while ((l = reader.read(buf)) != -1) {
						byteArray.write(buf, 0, l);
					}

					methed.addOtherData(sum, byteArray.toByteArray());

					client.close();
					dataServer.close();
				}
				System.out.println("server send data start");

				result=methed.output(sum, nodeNum+1);

				for (int i = 0; i < nodeNum; i++) {
					System.out.println("server send data:" + nodesIP.get(i) + ":" + nodesPort.get(i));
					client = new Socket(nodesIP.get(i), nodesPort.get(i));
					OutputStream writer = client.getOutputStream();

					writer.write(result);
					client.shutdownOutput();
					System.out.println("over");
				}
			} catch (IOException e) {
				throw new RuntimeException(e.toString());
			}
		} else {
			ServerSocket server;
			try {
				server = new ServerSocket(localPort);
			} catch (IOException e1) {
				throw new RuntimeException(e1.toString());
			}

			System.out.println(nodesIP.get(serverID) + ":" + nodesPort.get(serverID));

			while (true) {

				try {
					Socket client = new Socket(nodesIP.get(serverID), nodesPort.get(serverID));
					System.out.println("socket ok");
					OutputStream writer = client.getOutputStream();
					ByteArrayOutputStream byteArray = new ByteArrayOutputStream();

					writer.write(data.getBytes());
					client.shutdownOutput();

					Socket reciever = server.accept();
					InputStream reader = reciever.getInputStream();

					System.out.println("client start recieve data");

					byte[] buf = new byte[maxbuf];
					int l;
					while ((l = reader.read(buf)) != -1) {
						byteArray.write(buf, 0, l);
					}
					System.out.print("recieve over");

					reciever.close();
					server.close();
					System.out.println("client recieve data: " + byteArray.toString());

					result = byteArray.toByteArray();
				} catch (UnknownHostException e) {
					;
				} catch (IOException e) {
					;
				}

				if (result != null) {
					break;
				}
			}
		}

		return result;
	}

	private class ReactThread extends Thread {
		private String serverIP;
		private int port;

		public ReactThread(String IP, int port) {
			serverIP = IP;
			this.port = port;
		}

		@Override
		public void run() {
			while (true) {
				try {
					ServerSocket socket = new ServerSocket(port);
					Socket client = socket.accept();
					InputStream reader = client.getInputStream();
					ByteArrayOutputStream byteArray = new ByteArrayOutputStream();

					byte[] buf = new byte[20];
					int l;
					while ((l = reader.read(buf)) != -1) {
						byteArray.write(buf, 0, l);
					}

					String s = byteArray.toString();
					System.out.println(serverIP);

					OutputStream writer = client.getOutputStream();
					if (s.equals("c")) {
						System.out.println("send IP");
						writer.write(serverIP.getBytes());
					}
					client.shutdownOutput();

					socket.close();
					client.close();
					writer.close();
					reader.close();
					if (s.equals("o")) {
						break;
					}
				} catch (IOException e) {
					throw new RuntimeException(e.toString());
				}
			}
		}

	}
}
