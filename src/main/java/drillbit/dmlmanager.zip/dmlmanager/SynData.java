package drillbit.dmlmanager;

public interface SynData {
	void addData(byte[] data);
	
	void average(int num);
	
	byte[] getBytes();
	
	void fromBytes(byte[] data);
}
