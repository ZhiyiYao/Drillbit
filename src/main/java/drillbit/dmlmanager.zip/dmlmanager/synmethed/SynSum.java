package drillbit.dmlmanager.synmethed;

import drillbit.dmlmanager.SynData;

public class SynSum implements SynMethed {

	@Override
	public void addOtherData(SynData instance, byte[] data) {
		instance.addData(data);
	}

	@Override
	public byte[] output(SynData instance, int num) {
		return instance.getBytes();
	}

}
