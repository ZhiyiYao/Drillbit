package drillbit.dmlmanager.synmethed;

import drillbit.dmlmanager.SynData;

public interface SynMethed {
	void addOtherData(SynData instance, byte[] data);
	
	byte[] output(SynData instance,int num);
}
