package drillbit.dmlmanager.synmethed;

import drillbit.dmlmanager.SynData;

public class SynAvg implements SynMethed {

	@Override
	public void addOtherData(SynData instance, byte[] data) {
		instance.addData(data);
	}

	@Override
	public byte[] output(SynData instance, int num) {
		instance.average(num);
		return instance.getBytes();
	}

}
